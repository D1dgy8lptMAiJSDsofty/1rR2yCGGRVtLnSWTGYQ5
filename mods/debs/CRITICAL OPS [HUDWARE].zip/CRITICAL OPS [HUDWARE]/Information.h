#include <Hudware/Credits/Developer/Link/Telegram/RonnyDev.h>

/*

En:
To open the menu, press 2 times with 3 fingers anywhere on the screen!

RUS:
Для открытия меню нажмите 2 раза 3 пальцами в любое место на экране!

*/